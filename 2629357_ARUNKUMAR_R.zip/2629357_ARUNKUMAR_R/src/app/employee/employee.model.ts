export interface Employee{
    id:number | String,
    name:string,
    emailId:string,
    phoneNumber:number
}